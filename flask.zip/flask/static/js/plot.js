
$(document).ready(function(){
  $("button").click(function(){
    $("#div1").load("/pl");
  });

});

function showDiv1() {
   document.getElementById('div_1').style.display = "block";
}

function showDiv2() {
   document.getElementById('div_2').style.display = "block";
}

function showDiv3() {
   document.getElementById('div_3').style.display = "block";
}

function showDiv4() {
   document.getElementById('div_4').style.display = "block";
}

function showDiv5() {
   document.getElementById('div_5').style.display = "block";
}


function showDiv6() {
   document.getElementById('div_6').style.display = "block";
}

function showDiv7() {
   document.getElementById('div_7').style.display = "block";
}

function showDiv8() {
   document.getElementById('div_8').style.display = "block";
}

